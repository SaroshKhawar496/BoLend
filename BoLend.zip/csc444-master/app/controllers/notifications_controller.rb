class NotificationsController < ApplicationController
   
	def index
    @notifications = Notification.where(recipient: current_user).order(id: :desc)

    # paginate notifications
    @notifications = @notifications.page(page).per(per_page(30))
    @per_page = per_page.to_i
	end

  def mark_as_read
    @notifications = Notification.where(recipient: current_user).unread
    @notifications.update_all(read_at: Time.now.utc)
    render json: {success: true}
  end


end