class ConfirmationsController < Devise::ConfirmationsController  
	respond_to :json
	
end