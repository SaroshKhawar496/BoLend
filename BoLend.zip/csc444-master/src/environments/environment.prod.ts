export const environment = {
	production: true,
	baseUrl: 'https://www.444chan.com/api',
	forceImgHttps: true,
};
